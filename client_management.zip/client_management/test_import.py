try:
    from forms_module import ClientForm, ContactForm
    print("Import successful")
except ImportError as e:
    print(f"Import failed: {e}")
